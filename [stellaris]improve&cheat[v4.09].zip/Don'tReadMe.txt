代码-参考/搬运-名单(致谢名单):
	帝国规模:
		name:多彩银河作弊扩展
		id:2807369527
		creator:雷电

		name:帝国规模岗位
		id:2889563543
		creator:Epsilon-Farblos

		name:无限帝国规模
		name:Unlimited Empire Size
		id:3301557224
		creator:Rinmiolc

	作弊建筑:
		name:群星作弊扩展
		id:2828113512
		creator:Wscy

		name:多彩银河作弊扩展
		id:2807369527
		creator:雷电

	法令:
		name:群星作弊扩展
		id:2828113512
		creator:Wscy

		name:多彩银河作弊扩展
		id:2807369527
		creator:雷电

	行星改造:
		name:!伞の进阶飞升!/!Reworked Advanced Ascension
		id:1199002146
		creator:Kasako'小傘/scroll

		name:杂项优化
		id:2813316428
		creator:Elivicti_

		name:允许蜂巢使用星球塑形师/Allow hive mind used world shaper
		id:3131693801
		creator:别打游戏快去做模

		name:环境改造
		name:环境改造-向死寂星球进发
		id:3243279078
		creator:saber

	星球决议-可改造珍贵行星:
		name:杂项优化
		id:2813316428
		creator:Elivicti_

	星球决议-摧毁殖民地(抹除人口用):
		name:CPU Saver-Eliminate Owned Planets
		name:CPU拯救者，删除你自己的殖民地
		id:3027664248
		creator:Paddy32guan

	星球决议-删除行星:
		name:Decisions: Destroy the planet
		name:决议:毁灭星球
		id:2859776631
		creator:小裙子

	自动建设恒星基地&采矿站&研究站:
		name:auto build starbase
		name:自动建设恒星基地
		id:2801072378
		creator:一只小松鼠

		name:Automatic Build Mining/Research Station
		name:补充境内所有采矿/研究站
		id:2794110773
		creator:善良の熊

		(!!搬运自上两个mod) name:自动建设哨站和采矿科研站
		id:3117610987
		creator:Lonely_DM

		(!!搬运自上两个mod) name:自动建造边境哨站及境内采矿研究站-auto build starbase and mining station
		id:2812080132
		creator:152783536

	舰船设计和舰船区段、武器装甲、武器部件与泰坦光环:
		name:群星作弊扩展	(有可能有部分代码和思路来自下面那位?)
		id:2828113512
		creator:Wscy

		name:多彩银河作弊扩展
		id:2807369527
		creator:雷电

		name:第四天灾武器库
		id:2754319969
		creator:陌灬小泪

	武器特效:
		name:无我原非你，从他不解伊。(多彩银河图文资源包)
		id:2923834739
		creator:简言之

	星系编辑器-殖民地编辑器-帝国修正编辑器(部分创意想法、代码):
		name:Issras Cheat Menu
		id:3323443155
		creator:Issras

		name:Otter Editor
		id:1595999824
		creator:Seamoo

	自闭星系:
		name:自闭星系
		id:2844764915
		creator:蓬莱冰棒玉枝

		name:Extragalactic Cluster Start
		id:1999512770
		creator:Draconas

		name:缤纷多彩の银河(2.1.1)
		id:2748029219
		creator:简言之

	修改L星门内容:
		name:杂项优化
		id:2813316428
		creator:Elivicti_

	科技循环:

	禁止AI探索星界裂隙和发掘遗址:

	星河卫士&天灾飞升不冲突:



素材:
	决议:
		name:杂项优化
		id:2813316428
		creator:Elivicti_
	
	建筑:
		name:群星作弊扩展
		id:2828113512
		creator:Wscy

	武器素材:
		name:无我原非你，从他不解伊。(多彩银河图文资源包)
		id:2923834739
		creator:简言之

参考网址:
	https://qunxing.huijiwiki.com/wiki/%E4%BF%AE%E6%AD%A3%E8%A1%A8
	https://qunxing.huijiwiki.com/wiki/%E6%8E%A7%E5%88%B6%E5%8F%B0#.E8.88.B0.E8.88.B9.E7.94.9F.E6.88.90.E4.BB.A3.E7.A0.81
	https://qunxing.huijiwiki.com/wiki/%E4%BA%BA%E5%8F%A3
	https://main--pdxdoc-next.netlify.app/guides/localisation/
	https://tieba.baidu.com/p/7125108228
	https://www.bilibili.com/read/cv25392805/
	https://www.bilibili.com/read/cv12701133/

其他参考内容均来自游戏[stellaris][群星]